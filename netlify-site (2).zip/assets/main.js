
const WA="14077912908",$=id=>document.getElementById(id);
// hero video loads after the page is ready, never blocks first paint
addEventListener("load",()=>{const v=$("hv"),sd=navigator.connection&&navigator.connection.saveData;
 if(matchMedia("(prefers-reduced-motion: reduce)").matches||sd)return;
 v.src="assets/hero.mp4";v.oncanplay=()=>{v.classList.add("on");v.play().catch(()=>{})};v.load()});
// service quick-pick
document.querySelectorAll("[data-pick]").forEach(a=>a.addEventListener("click",()=>{$("svc").value=a.dataset.pick}));
// booking -> WhatsApp
$("date").min=new Date().toISOString().slice(0,10);
const wa=t=>window.open(`https://wa.me/${WA}?text=${encodeURIComponent(t)}`,"_blank","noopener");
$("f").onsubmit=e=>{e.preventDefault();const n=$("name").value.trim(),p=$("phone").value.trim();
 if(!$("date").value)return $("err").textContent="Choose a preferred date.";
 if(!$("car").value.trim())return $("err").textContent="Enter your vehicle.";
 if(n.length<2)return $("err").textContent="Enter your name.";
 if(p.replace(/\D/g,"").length<10)return $("err").textContent="Enter a phone number with area code.";
 $("err").textContent="";
 fetch("/",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams(new FormData($("f"))).toString(),keepalive:true}).catch(()=>{});
 wa(`Hi, I’d like to book: ${$("svc").value}\nDate: ${$("date").value} (${$("time").value})\nVehicle: ${$("car").value}\nName: ${n}\nPhone: ${p}`)};
// whatsapp widget
$("wab").onclick=()=>{const o=$("wap").classList.toggle("open");$("wab").setAttribute("aria-expanded",o)};
$("was").onclick=()=>wa($("wam").value.trim()||"Hi, I have a question about your services.");
