Deploy on Netlify
1. Drag this whole folder onto https://app.netlify.com/drop  (or: connect the folder to a Git repo, publish directory ".", no build command).
2. Forms: Netlify > Forms > booking. Add an email notification under Site configuration > Forms.
3. Replace assets/favicon.svg and the logo in index.html if the client has an official logo.
Note: assets use fixed names. If you replace a file, keep the same name, or the browser may show the cached copy (they are cached for a year).
